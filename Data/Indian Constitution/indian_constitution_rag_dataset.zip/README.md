# Indian Constitution RAG Dataset

## Recommended ingestion pattern

1.  Load `indian_constitution_rag_chunks.jsonl` into the vector
    database.
2.  Embed the `text` field.
3.  Store the `metadata` object unchanged as vector metadata.
4.  Use `parent_id` for parent-document retrieval / context expansion.
5.  Filter or boost on `part`, `article`, `chapter`, and `status` when
    useful.
6.  For final answers, cite `page_start`/`page_end` and the
    Article/Schedule identifier.

## Dataset design

The Constitution is treated as a hierarchical legal document:

-   Preamble
-   Part
-   Chapter
-   Article
-   Clause/sub-clause text
-   Schedule
-   Appendix

Long Articles are split into smaller retrieval chunks while retaining
the Article identity and page range.

## Files

-   `indian_constitution_rag_chunks.jsonl` --- primary RAG/vector-store
    corpus.
-   `indian_constitution_rag_documents.csv` --- parent-level documents
    for inspection, reranking, or parent retrieval.
-   `indian_constitution_retrieval_eval.jsonl` --- 978 deterministic
    retrieval test queries with relevant parent/chunk IDs.
-   `indian_constitution_rag_manifest.json` --- schema and dataset
    statistics.

## Important legal-data behavior

Amendment footnotes are preserved rather than discarded. Omitted
Articles are represented explicitly with `status = omitted`.

This dataset is for retrieval/chatbot development; a production legal
chatbot should still display source citations and avoid treating
retrieved text as legal advice.
